def test(data):
	print "NEWHAND\n"